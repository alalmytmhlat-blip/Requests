"""يُشغَّل بعد `flutter create` لتعديل ملفات المنصات المولَّدة.

أهم ما يفعله: إضافة صلاحية INTERNET إلى نسخة release في أندرويد
(قالب Flutter يضيفها لنسخ debug/profile فقط، فيتوقف الاتصال بالخادم في APK النهائي).
"""
import json
import pathlib
import re

APP_NAME = "طلبات"

manifest = pathlib.Path("android/app/src/main/AndroidManifest.xml")
if manifest.exists():
    text = manifest.read_text(encoding="utf-8")
    for perm in ("INTERNET", "ACCESS_NETWORK_STATE"):
        tag = f'<uses-permission android:name="android.permission.{perm}"'
        if tag not in text:
            text = re.sub(r"(<manifest[^>]*>)", lambda m: m.group(1) + "\n    " + tag + " />", text, count=1)
    text = re.sub(r'android:label="[^"]*"', f'android:label="{APP_NAME}"', text, count=1)
    manifest.write_text(text, encoding="utf-8")
    print("patched", manifest)

index = pathlib.Path("web/index.html")
if index.exists():
    html = index.read_text(encoding="utf-8")
    html = re.sub(r"<title>.*?</title>", f"<title>{APP_NAME}</title>", html, flags=re.S)
    html = re.sub(
        r'(<meta name="apple-mobile-web-app-title" content=")[^"]*(")',
        lambda m: m.group(1) + APP_NAME + m.group(2),
        html,
    )
    index.write_text(html, encoding="utf-8")
    print("patched", index)

web_manifest = pathlib.Path("web/manifest.json")
if web_manifest.exists():
    data = json.loads(web_manifest.read_text(encoding="utf-8"))
    data.update({"name": APP_NAME, "short_name": APP_NAME, "lang": "ar", "dir": "rtl"})
    web_manifest.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print("patched", web_manifest)
