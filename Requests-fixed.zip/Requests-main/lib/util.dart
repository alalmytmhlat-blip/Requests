const kStatuses = ['جديد', 'قيد التجهيز', 'تم توفيره', 'غير متوفر'];

/// يحوّل نص الكمية إلى رقم. يقبل الأرقام العربية (٣) والفارسية (۳)
/// والفاصلة العربية (٫ ،) ويرفض الصفر والسالب وغير الرقمي.
double? parseQty(String input) {
  const arabic = '٠١٢٣٤٥٦٧٨٩';
  const persian = '۰۱۲۳۴۵۶۷۸۹';
  var t = input
      .trim()
      .replaceAll('٫', '.')
      .replaceAll('،', '.')
      .replaceAll(',', '.');
  for (var i = 0; i < 10; i++) {
    t = t.replaceAll(arabic[i], '$i').replaceAll(persian[i], '$i');
  }
  final v = double.tryParse(t);
  if (v == null || v.isNaN || v.isInfinite || v <= 0) return null;
  return v;
}

String normalize(String s) => s.trim().replaceAll(RegExp(r'\s+'), ' ');

String formatQty(num q) =>
    q == q.roundToDouble() ? q.toInt().toString() : q.toString();

String formatDate(DateTime d) {
  String two(int n) => n.toString().padLeft(2, '0');
  return '${d.year}/${two(d.month)}/${two(d.day)}  ${two(d.hour)}:${two(d.minute)}';
}

final _usernameRe = RegExp(r'^[a-zA-Z0-9._-]{3,30}$');

bool validUsername(String s) => _usernameRe.hasMatch(s.trim());

/// اسم الدخول (مثل رقم الهاتف) يُحوَّل داخليًا إلى بريد لاستخدام Firebase Auth.
String usernameToEmail(String s) => '${s.trim().toLowerCase()}@alalamiya.app';

String authMessage(String code) {
  switch (code) {
    case 'invalid-credential':
    case 'wrong-password':
    case 'user-not-found':
    case 'invalid-email':
      return 'اسم الدخول أو كلمة المرور غير صحيحة';
    case 'email-already-in-use':
      return 'اسم الدخول مستخدم مسبقًا';
    case 'weak-password':
      return 'كلمة المرور ضعيفة (6 أحرف على الأقل)';
    case 'network-request-failed':
      return 'لا يوجد اتصال بالإنترنت';
    case 'too-many-requests':
      return 'محاولات كثيرة، حاول لاحقًا';
    case 'operation-not-allowed':
      return 'تسجيل الدخول بالبريد/كلمة المرور غير مفعّل في Firebase';
    case 'user-disabled':
      return 'هذا الحساب معطّل';
    default:
      return 'تعذر تسجيل الدخول ($code)';
  }
}
