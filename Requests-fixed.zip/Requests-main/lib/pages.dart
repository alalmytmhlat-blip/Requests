import 'dart:async';
import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'data.dart';
import 'util.dart';

// =====================================================================
// عناصر مشتركة
// =====================================================================

Future<bool> _confirm(BuildContext context, String message) async {
  final ok = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      content: Text(message),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(c, false),
          child: const Text('إلغاء'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(c, true),
          child: const Text('تأكيد'),
        ),
      ],
    ),
  );
  return ok == true;
}

class _Splash extends StatelessWidget {
  const _Splash({this.message});
  final String? message;

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const CircularProgressIndicator(),
              if (message != null) ...[
                const SizedBox(height: 16),
                Text(message!),
              ],
            ],
          ),
        ),
      );
}

class _MessageView extends StatelessWidget {
  const _MessageView({
    required this.icon,
    required this.text,
    this.onRetry,
    this.showSignOut = true,
  });

  final IconData icon;
  final String text;
  final VoidCallback? onRetry;
  final bool showSignOut;

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 420),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(icon, size: 64, color: Theme.of(context).colorScheme.primary),
                  const SizedBox(height: 16),
                  Text(text, textAlign: TextAlign.center),
                  const SizedBox(height: 24),
                  if (onRetry != null)
                    FilledButton.icon(
                      onPressed: onRetry,
                      icon: const Icon(Icons.refresh),
                      label: const Text('إعادة المحاولة'),
                    ),
                  if (showSignOut) ...[
                    const SizedBox(height: 8),
                    OutlinedButton.icon(
                      onPressed: Repo.i.signOut,
                      icon: const Icon(Icons.logout),
                      label: const Text('تسجيل الخروج'),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      );
}

class _Logo extends StatelessWidget {
  const _Logo({required this.business, this.size = 40});
  final Business business;
  final double size;

  @override
  Widget build(BuildContext context) {
    final bytes = business.logoBytes;
    if (bytes != null) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Image.memory(
          bytes,
          width: size,
          height: size,
          fit: BoxFit.contain,
          errorBuilder: (_, __, ___) => Icon(Icons.storefront, size: size),
        ),
      );
    }
    return Icon(
      Icons.storefront,
      size: size,
      color: Theme.of(context).colorScheme.primary,
    );
  }
}

Color _statusColor(String s) {
  switch (s) {
    case 'قيد التجهيز':
      return Colors.orange;
    case 'تم توفيره':
      return Colors.green;
    case 'غير متوفر':
      return Colors.red;
    default:
      return Colors.blue;
  }
}

class _StatusChip extends StatelessWidget {
  const _StatusChip(this.status);
  final String status;

  @override
  Widget build(BuildContext context) => Chip(
        label: Text(status),
        backgroundColor: _statusColor(status).withValues(alpha: 0.15),
        side: BorderSide.none,
        visualDensity: VisualDensity.compact,
      );
}

// =====================================================================
// الإعداد الناقص
// =====================================================================

class SetupNeededPage extends StatelessWidget {
  const SetupNeededPage({super.key});

  @override
  Widget build(BuildContext context) => const _MessageView(
        icon: Icons.settings_suggest,
        showSignOut: false,
        text: 'التطبيق غير مربوط بالخادم بعد.\n'
            'أضف مفاتيح Firebase في GitHub Secrets ثم أعد البناء.\n'
            'الخطوات في ملف README.md.',
      );
}

// =====================================================================
// بوابة الدخول
// =====================================================================

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) => StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const _Splash();
          }
          final user = snap.data;
          if (user == null) return const LoginPage();
          return _UserGate(key: ValueKey(user.uid), user: user);
        },
      );
}

class _UserGate extends StatefulWidget {
  const _UserGate({super.key, required this.user});
  final User user;

  @override
  State<_UserGate> createState() => _UserGateState();
}

class _UserGateState extends State<_UserGate> {
  late final Stream<DocumentSnapshot<Map<String, dynamic>>> _stream =
      Repo.i.userDoc(widget.user.uid);
  bool _creating = false;
  String? _error;

  void _create() {
    if (_creating) return;
    _creating = true;
    Repo.i.ensureUserDoc(widget.user).then((_) {
      _creating = false;
    }).catchError((Object e) {
      _creating = false;
      if (mounted) {
        setState(() => _error = 'تعذر تجهيز الحساب. تأكد من الاتصال بالإنترنت.');
      }
    });
  }

  @override
  Widget build(BuildContext context) =>
      StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: _stream,
        builder: (context, snap) {
          if (snap.hasError) {
            return _MessageView(
              icon: Icons.error_outline,
              text: 'تعذر الاتصال بالخادم أو لا تملك صلاحية.\n${snap.error}',
            );
          }
          if (snap.connectionState == ConnectionState.waiting) {
            return const _Splash();
          }
          final doc = snap.data;
          if (doc == null) return const _Splash();
          if (!doc.exists) {
            if (_error != null) {
              return _MessageView(
                icon: Icons.wifi_off,
                text: _error!,
                onRetry: () {
                  setState(() => _error = null);
                  _create();
                },
              );
            }
            _create();
            return const _Splash(message: 'جاري تجهيز حسابك…');
          }
          final u = AppUser.fromDoc(doc);
          if (!u.approved) return PendingPage(user: u);
          return HomePage(key: ValueKey('${u.uid}-${u.role}'), user: u);
        },
      );
}

class PendingPage extends StatelessWidget {
  const PendingPage({super.key, required this.user});
  final AppUser user;

  @override
  Widget build(BuildContext context) => _MessageView(
        icon: Icons.hourglass_top,
        text: 'مرحبًا ${user.name}\n'
            'حسابك بانتظار موافقة المسؤول.\n'
            'سيفتح التطبيق تلقائيًا فور اعتماده.',
      );
}

// =====================================================================
// تسجيل الدخول / إنشاء حساب
// =====================================================================

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _name = TextEditingController();
  final _user = TextEditingController();
  final _pass = TextEditingController();
  bool _signUp = false;
  bool _busy = false;
  bool _hide = true;
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    _user.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final username = _user.text.trim();
    final pass = _pass.text;
    final name = normalize(_name.text);
    if (!validUsername(username)) {
      setState(() => _error =
          'اسم الدخول: من 3 إلى 30 حرفًا إنجليزيًا أو أرقامًا (يمكنك استخدام رقم هاتفك)');
      return;
    }
    if (pass.length < 6) {
      setState(() => _error = 'كلمة المرور 6 أحرف على الأقل');
      return;
    }
    if (_signUp && name.isEmpty) {
      setState(() => _error = 'اكتب اسمك الظاهر');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      if (_signUp) {
        await Repo.i.signUp(username, pass, name);
      } else {
        await Repo.i.signIn(username, pass);
      }
    } on FirebaseAuthException catch (e) {
      if (mounted) setState(() => _error = authMessage(e.code));
    } catch (e) {
      if (mounted) setState(() => _error = 'حدث خطأ غير متوقع: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Icon(
                        Icons.storefront,
                        size: 56,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _signUp ? 'إنشاء حساب عامل' : 'تسجيل الدخول',
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      const SizedBox(height: 16),
                      if (_signUp) ...[
                        TextField(
                          controller: _name,
                          decoration: const InputDecoration(
                            labelText: 'الاسم الظاهر',
                            border: OutlineInputBorder(),
                          ),
                        ),
                        const SizedBox(height: 12),
                      ],
                      TextField(
                        controller: _user,
                        keyboardType: TextInputType.emailAddress,
                        autocorrect: false,
                        decoration: const InputDecoration(
                          labelText: 'اسم الدخول (رقم الهاتف مثلًا)',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _pass,
                        obscureText: _hide,
                        onSubmitted: (_) => _busy ? null : _submit(),
                        decoration: InputDecoration(
                          labelText: 'كلمة المرور',
                          border: const OutlineInputBorder(),
                          suffixIcon: IconButton(
                            icon: Icon(
                              _hide ? Icons.visibility : Icons.visibility_off,
                            ),
                            onPressed: () => setState(() => _hide = !_hide),
                          ),
                        ),
                      ),
                      if (_error != null) ...[
                        const SizedBox(height: 12),
                        Text(
                          _error!,
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.error,
                          ),
                        ),
                      ],
                      const SizedBox(height: 16),
                      FilledButton(
                        onPressed: _busy ? null : _submit,
                        child: _busy
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : Text(_signUp ? 'إنشاء الحساب' : 'دخول'),
                      ),
                      TextButton(
                        onPressed: _busy
                            ? null
                            : () => setState(() {
                                  _signUp = !_signUp;
                                  _error = null;
                                }),
                        child: Text(
                          _signUp
                              ? 'لدي حساب بالفعل'
                              : 'عامل جديد؟ أنشئ حسابًا',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      );
}

// =====================================================================
// الصفحة الرئيسية (متجاوبة: شريط سفلي للجوال، شريط جانبي للشاشات الكبيرة)
// =====================================================================

class _TabDef {
  _TabDef(this.key, this.icon, this.label, this.page);
  final String key;
  final IconData icon;
  final String label;
  final Widget page;
}

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.user});
  final AppUser user;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _tab = 0;
  late final Stream<Business> _business = Repo.i.business();
  StreamSubscription<String>? _errorSub;

  @override
  void initState() {
    super.initState();
    _errorSub = Repo.i.errors.listen((m) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
    });
  }

  @override
  void dispose() {
    _errorSub?.cancel();
    super.dispose();
  }

  Future<void> _addRequest() async {
    final messenger = ScaffoldMessenger.of(context);
    final items = await Repo.i.items().first;
    if (!mounted) return;
    if (items.isEmpty) {
      messenger.showSnackBar(
        const SnackBar(content: Text('أضف الأصناف أولاً من قسم الأصناف')),
      );
      return;
    }
    final res = await showDialog<Map<String, Object>>(
      context: context,
      builder: (_) => _RequestDialog(items: items),
    );
    if (res == null) return;
    Repo.i.addRequest(
      item: res['item'] as Item,
      qty: res['qty'] as double,
      note: res['note'] as String,
      user: widget.user,
    );
    messenger.showSnackBar(
      const SnackBar(
        content: Text('تم تسجيل الطلب (يُرسل تلقائيًا عند توفر الإنترنت)'),
      ),
    );
  }

  Future<void> _addItem() async {
    final messenger = ScaffoldMessenger.of(context);
    final res = await showDialog<Map<String, String>>(
      context: context,
      builder: (_) => const _ItemDialog(),
    );
    if (res == null) return;
    final items = await Repo.i.items().first;
    final name = res['name']!;
    final category = res['category']!;
    final dup = items.any(
      (e) =>
          e.name.toLowerCase() == name.toLowerCase() &&
          e.category.toLowerCase() == category.toLowerCase(),
    );
    if (dup) {
      messenger.showSnackBar(
        const SnackBar(content: Text('هذا الصنف موجود مسبقًا في نفس التصنيف')),
      );
      return;
    }
    Repo.i.addItem(
      name: name,
      category: category,
      unit: res['unit']!,
      user: widget.user,
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = widget.user;
    return StreamBuilder<Business>(
      stream: _business,
      initialData: Business.defaults(),
      builder: (context, snap) {
        final b = snap.data ?? Business.defaults();
        final tabs = <_TabDef>[
          _TabDef('requests', Icons.receipt_long, 'الطلبات',
              _RequestsTab(user: user)),
          _TabDef('items', Icons.category, 'الأصناف', _ItemsTab(user: user)),
          if (user.isAdmin)
            _TabDef('users', Icons.group, 'المستخدمون', _UsersTab(me: user)),
          _TabDef('settings', Icons.store, 'الإعدادات',
              _SettingsTab(user: user, business: b)),
        ];
        final index = _tab.clamp(0, tabs.length - 1);
        final current = tabs[index];
        final wide = MediaQuery.sizeOf(context).width >= 800;

        Widget? fab;
        if (current.key == 'requests') {
          fab = FloatingActionButton.extended(
            onPressed: _addRequest,
            icon: const Icon(Icons.add),
            label: const Text('طلب نقص'),
          );
        } else if (current.key == 'items') {
          fab = FloatingActionButton.extended(
            onPressed: _addItem,
            icon: const Icon(Icons.add),
            label: const Text('صنف جديد'),
          );
        }

        final body = Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 800),
            child: current.page,
          ),
        );

        return Scaffold(
          appBar: AppBar(
            title: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _Logo(business: b, size: 32),
                const SizedBox(width: 10),
                Flexible(
                  child: Text(
                    b.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
              ],
            ),
          ),
          body: wide
              ? Row(
                  children: [
                    NavigationRail(
                      selectedIndex: index,
                      labelType: NavigationRailLabelType.all,
                      onDestinationSelected: (v) => setState(() => _tab = v),
                      destinations: [
                        for (final t in tabs)
                          NavigationRailDestination(
                            icon: Icon(t.icon),
                            label: Text(t.label),
                          ),
                      ],
                    ),
                    const VerticalDivider(width: 1),
                    Expanded(child: body),
                  ],
                )
              : body,
          bottomNavigationBar: wide
              ? null
              : NavigationBar(
                  selectedIndex: index,
                  onDestinationSelected: (v) => setState(() => _tab = v),
                  destinations: [
                    for (final t in tabs)
                      NavigationDestination(icon: Icon(t.icon), label: t.label),
                  ],
                ),
          floatingActionButton: fab,
        );
      },
    );
  }
}

// =====================================================================
// الطلبات
// =====================================================================

class _RequestsTab extends StatefulWidget {
  const _RequestsTab({required this.user});
  final AppUser user;

  @override
  State<_RequestsTab> createState() => _RequestsTabState();
}

class _RequestsTabState extends State<_RequestsTab> {
  late final Stream<List<Req>> _stream = Repo.i.requests(widget.user);
  String _query = '';
  String? _status;

  Widget _chip(String label, String? value) => Padding(
        padding: const EdgeInsetsDirectional.only(end: 8),
        child: ChoiceChip(
          label: Text(label),
          selected: _status == value,
          onSelected: (_) => setState(() => _status = value),
        ),
      );

  String _subtitle(Req r) {
    final lines = <String>['الكمية: ${formatQty(r.qty)} • ${r.workerName}'];
    if (r.note.isNotEmpty) lines.add(r.note);
    lines.add(formatDate(r.createdAt) + (r.pending ? ' • بانتظار المزامنة' : ''));
    return lines.join('\n');
  }

  Future<void> _onMenu(Req r, String v) async {
    if (v == '__delete') {
      final ok = await _confirm(context, 'حذف طلب "${r.itemName}"؟');
      if (ok) Repo.i.deleteRequest(r.id);
    } else {
      Repo.i.setStatus(r.id, v);
    }
  }

  @override
  Widget build(BuildContext context) {
    final admin = widget.user.isAdmin;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
          child: TextField(
            decoration: const InputDecoration(
              prefixIcon: Icon(Icons.search),
              hintText: 'بحث باسم الصنف أو العامل',
              border: OutlineInputBorder(),
              isDense: true,
            ),
            onChanged: (v) => setState(() => _query = v.trim()),
          ),
        ),
        SizedBox(
          height: 52,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            children: [
              _chip('الكل', null),
              for (final s in kStatuses) _chip(s, s),
            ],
          ),
        ),
        Expanded(
          child: StreamBuilder<List<Req>>(
            stream: _stream,
            builder: (context, snap) {
              if (snap.hasError) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text('تعذر تحميل الطلبات\n${snap.error}',
                        textAlign: TextAlign.center),
                  ),
                );
              }
              if (!snap.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              final all = snap.data!;
              final q = _query.toLowerCase();
              final list = all.where((r) {
                if (_status != null && r.status != _status) return false;
                if (q.isEmpty) return true;
                return r.itemName.toLowerCase().contains(q) ||
                    r.workerName.toLowerCase().contains(q);
              }).toList();
              if (list.isEmpty) {
                return Center(
                  child: Text(all.isEmpty ? 'لا توجد طلبات بعد' : 'لا نتائج مطابقة'),
                );
              }
              return ListView.builder(
                padding: const EdgeInsets.only(bottom: 88),
                itemCount: list.length,
                itemBuilder: (context, i) {
                  final r = list[i];
                  return Card(
                    margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                    child: ListTile(
                      leading: Icon(
                        r.pending
                            ? Icons.cloud_upload_outlined
                            : Icons.inventory_2_outlined,
                      ),
                      title: Text(r.itemName),
                      subtitle: Text(_subtitle(r)),
                      isThreeLine: true,
                      trailing: admin
                          ? PopupMenuButton<String>(
                              onSelected: (v) => _onMenu(r, v),
                              itemBuilder: (_) => <PopupMenuEntry<String>>[
                                for (final s in kStatuses)
                                  PopupMenuItem<String>(value: s, child: Text(s)),
                                const PopupMenuDivider(),
                                const PopupMenuItem<String>(
                                  value: '__delete',
                                  child: Text('حذف الطلب'),
                                ),
                              ],
                              child: _StatusChip(r.status),
                            )
                          : _StatusChip(r.status),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}

class _RequestDialog extends StatefulWidget {
  const _RequestDialog({required this.items});
  final List<Item> items;

  @override
  State<_RequestDialog> createState() => _RequestDialogState();
}

class _RequestDialogState extends State<_RequestDialog> {
  Item? _selected;
  final _qty = TextEditingController(text: '1');
  final _note = TextEditingController();
  String? _error;

  @override
  void dispose() {
    _qty.dispose();
    _note.dispose();
    super.dispose();
  }

  void _submit() {
    final q = parseQty(_qty.text);
    if (_selected == null) {
      setState(() => _error = 'اختر صنفًا من القائمة');
      return;
    }
    if (q == null) {
      setState(() => _error = 'أدخل كمية صحيحة أكبر من صفر');
      return;
    }
    Navigator.pop<Map<String, Object>>(context, {
      'item': _selected!,
      'qty': q,
      'note': _note.text.trim(),
    });
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: const Text('تسجيل صنف ناقص'),
        content: SizedBox(
          width: 400,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Autocomplete<Item>(
                  displayStringForOption: (e) => e.name,
                  optionsBuilder: (v) {
                    final q = v.text.trim().toLowerCase();
                    if (q.isEmpty) return widget.items.take(20);
                    return widget.items
                        .where((e) =>
                            e.name.toLowerCase().contains(q) ||
                            e.category.toLowerCase().contains(q))
                        .take(30);
                  },
                  onSelected: (e) => setState(() => _selected = e),
                  fieldViewBuilder: (context, controller, focusNode, _) =>
                      TextField(
                    controller: controller,
                    focusNode: focusNode,
                    decoration: const InputDecoration(
                      labelText: 'الصنف (اكتب للبحث)',
                      prefixIcon: Icon(Icons.search),
                    ),
                    onChanged: (t) {
                      if (_selected != null && t != _selected!.name) {
                        setState(() => _selected = null);
                      }
                    },
                  ),
                ),
                TextField(
                  controller: _qty,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  decoration: InputDecoration(
                    labelText: 'الكمية المطلوبة',
                    suffixText: _selected?.unit,
                  ),
                ),
                TextField(
                  controller: _note,
                  decoration: const InputDecoration(labelText: 'ملاحظات / مواصفات'),
                ),
                if (_error != null) ...[
                  const SizedBox(height: 12),
                  Text(
                    _error!,
                    style: TextStyle(color: Theme.of(context).colorScheme.error),
                  ),
                ],
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          FilledButton(onPressed: _submit, child: const Text('إرسال للمراجعة')),
        ],
      );
}

// =====================================================================
// الأصناف
// =====================================================================

class _ItemsTab extends StatefulWidget {
  const _ItemsTab({required this.user});
  final AppUser user;

  @override
  State<_ItemsTab> createState() => _ItemsTabState();
}

class _ItemsTabState extends State<_ItemsTab> {
  late final Stream<List<Item>> _stream = Repo.i.items();
  String _query = '';

  Future<void> _edit(Item e) async {
    final res = await showDialog<Map<String, String>>(
      context: context,
      builder: (_) => _ItemDialog(item: e),
    );
    if (res == null) return;
    Repo.i.updateItem(
      e.id,
      name: res['name']!,
      category: res['category']!,
      unit: res['unit']!,
    );
  }

  Future<void> _delete(Item e) async {
    final ok = await _confirm(context, 'حذف الصنف "${e.name}"؟');
    if (ok) Repo.i.deleteItem(e.id);
  }

  @override
  Widget build(BuildContext context) {
    final admin = widget.user.isAdmin;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
          child: TextField(
            decoration: const InputDecoration(
              prefixIcon: Icon(Icons.search),
              hintText: 'بحث بالاسم أو التصنيف',
              border: OutlineInputBorder(),
              isDense: true,
            ),
            onChanged: (v) => setState(() => _query = v.trim()),
          ),
        ),
        Expanded(
          child: StreamBuilder<List<Item>>(
            stream: _stream,
            builder: (context, snap) {
              if (snap.hasError) {
                return Center(child: Text('تعذر تحميل الأصناف\n${snap.error}'));
              }
              if (!snap.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              final all = snap.data!;
              final q = _query.toLowerCase();
              final list = q.isEmpty
                  ? all
                  : all
                      .where((e) =>
                          e.name.toLowerCase().contains(q) ||
                          e.category.toLowerCase().contains(q))
                      .toList();
              if (list.isEmpty) {
                return Center(
                  child: Text(all.isEmpty ? 'لم تتم إضافة أصناف' : 'لا نتائج مطابقة'),
                );
              }
              return ListView.builder(
                padding: const EdgeInsets.only(bottom: 88),
                itemCount: list.length,
                itemBuilder: (context, i) {
                  final e = list[i];
                  return Card(
                    margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    child: ListTile(
                      leading: const Icon(Icons.category_outlined),
                      title: Text(e.name),
                      subtitle: Text('التصنيف: ${e.category} • الوحدة: ${e.unit}'),
                      trailing: admin
                          ? PopupMenuButton<String>(
                              onSelected: (v) => v == 'edit' ? _edit(e) : _delete(e),
                              itemBuilder: (_) => const <PopupMenuEntry<String>>[
                                PopupMenuItem<String>(
                                  value: 'edit',
                                  child: Text('تعديل'),
                                ),
                                PopupMenuItem<String>(
                                  value: 'delete',
                                  child: Text('حذف'),
                                ),
                              ],
                            )
                          : null,
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}

class _ItemDialog extends StatefulWidget {
  const _ItemDialog({this.item});
  final Item? item;

  @override
  State<_ItemDialog> createState() => _ItemDialogState();
}

class _ItemDialogState extends State<_ItemDialog> {
  late final _name = TextEditingController(text: widget.item?.name ?? '');
  late final _category = TextEditingController(text: widget.item?.category ?? '');
  late final _unit = TextEditingController(text: widget.item?.unit ?? 'حبة');
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    _category.dispose();
    _unit.dispose();
    super.dispose();
  }

  void _submit() {
    final n = normalize(_name.text);
    final c = normalize(_category.text);
    final u = normalize(_unit.text);
    if (n.isEmpty || c.isEmpty) {
      setState(() => _error = 'اسم الصنف والتصنيف مطلوبان');
      return;
    }
    Navigator.pop<Map<String, String>>(context, {
      'name': n,
      'category': c,
      'unit': u.isEmpty ? 'حبة' : u,
    });
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: Text(widget.item == null ? 'إضافة صنف جديد' : 'تعديل الصنف'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _name,
                decoration: const InputDecoration(labelText: 'اسم الصنف'),
              ),
              TextField(
                controller: _category,
                decoration: const InputDecoration(labelText: 'تصنيف الصنف'),
              ),
              TextField(
                controller: _unit,
                decoration: const InputDecoration(labelText: 'وحدة القياس'),
              ),
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(
                  _error!,
                  style: TextStyle(color: Theme.of(context).colorScheme.error),
                ),
              ],
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          FilledButton(onPressed: _submit, child: const Text('حفظ')),
        ],
      );
}

// =====================================================================
// المستخدمون (للمسؤول فقط)
// =====================================================================

class _UsersTab extends StatefulWidget {
  const _UsersTab({required this.me});
  final AppUser me;

  @override
  State<_UsersTab> createState() => _UsersTabState();
}

class _UsersTabState extends State<_UsersTab> {
  late final Stream<List<AppUser>> _stream = Repo.i.users();

  @override
  Widget build(BuildContext context) => StreamBuilder<List<AppUser>>(
        stream: _stream,
        builder: (context, snap) {
          if (snap.hasError) {
            return Center(child: Text('تعذر تحميل المستخدمين\n${snap.error}'));
          }
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final list = snap.data!;
          return ListView.builder(
            padding: const EdgeInsets.only(top: 8, bottom: 24),
            itemCount: list.length,
            itemBuilder: (context, i) {
              final u = list[i];
              final isMe = u.uid == widget.me.uid;
              final roleLabel = u.role == 'admin' ? 'مسؤول' : 'عامل';
              final stateLabel = u.approved ? 'مفعّل' : 'بانتظار الموافقة';
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                child: ListTile(
                  leading: CircleAvatar(
                    child: Icon(
                      u.role == 'admin' ? Icons.admin_panel_settings : Icons.person,
                    ),
                  ),
                  title: Text(u.name),
                  subtitle: Text('$roleLabel • $stateLabel'),
                  trailing: isMe
                      ? const Text('أنت')
                      : Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Switch(
                              value: u.approved,
                              onChanged: (v) => Repo.i.setUser(u.uid, approved: v),
                            ),
                            PopupMenuButton<String>(
                              onSelected: (v) => Repo.i.setUser(u.uid, role: v),
                              itemBuilder: (_) => const <PopupMenuEntry<String>>[
                                PopupMenuItem<String>(
                                  value: 'worker',
                                  child: Text('عامل'),
                                ),
                                PopupMenuItem<String>(
                                  value: 'admin',
                                  child: Text('مسؤول'),
                                ),
                              ],
                            ),
                          ],
                        ),
                ),
              );
            },
          );
        },
      );
}

// =====================================================================
// الإعدادات
// =====================================================================

class _SettingsTab extends StatelessWidget {
  const _SettingsTab({required this.user, required this.business});
  final AppUser user;
  final Business business;

  Future<void> _pickLogo(BuildContext context) async {
    final messenger = ScaffoldMessenger.of(context);
    final picked = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      maxWidth: 300,
      maxHeight: 300,
      imageQuality: 80,
    );
    if (picked == null) return;
    final bytes = await picked.readAsBytes();
    if (bytes.length > 400 * 1024) {
      messenger.showSnackBar(
        const SnackBar(content: Text('حجم الصورة كبير؛ اختر صورة أصغر')),
      );
      return;
    }
    Repo.i.saveBusiness({'logoB64': base64Encode(bytes)});
  }

  Future<void> _editBusiness(BuildContext context) async {
    final n = TextEditingController(text: business.name);
    final a = TextEditingController(text: business.address);
    final p1 = TextEditingController(text: business.phone1);
    final p2 = TextEditingController(text: business.phone2);
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('إعدادات النشاط'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: n,
                decoration: const InputDecoration(labelText: 'اسم النشاط'),
              ),
              TextField(
                controller: a,
                decoration: const InputDecoration(labelText: 'العنوان'),
              ),
              TextField(
                controller: p1,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'رقم الهاتف الأول'),
              ),
              TextField(
                controller: p2,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'رقم الهاتف الثاني'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(c, true),
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
    if (ok == true && n.text.trim().isNotEmpty) {
      Repo.i.saveBusiness({
        'name': normalize(n.text),
        'address': normalize(a.text),
        'phone1': p1.text.trim(),
        'phone2': p2.text.trim(),
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final phones = [business.phone1, business.phone2]
        .where((s) => s.isNotEmpty)
        .join(' • ');
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Center(child: _Logo(business: business, size: 96)),
        const SizedBox(height: 8),
        Center(
          child: Text(
            business.name,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.titleLarge,
          ),
        ),
        const SizedBox(height: 12),
        if (user.isAdmin)
          OutlinedButton.icon(
            onPressed: () => _pickLogo(context),
            icon: const Icon(Icons.image),
            label: const Text('اختيار شعار النشاط'),
          ),
        ListTile(
          leading: const Icon(Icons.location_on),
          title: Text(business.address.isEmpty ? 'أضف عنوان النشاط' : business.address),
        ),
        ListTile(
          leading: const Icon(Icons.phone),
          title: Text(phones.isEmpty ? 'أضف أرقام التواصل' : phones),
        ),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.person),
          title: Text('المستخدم: ${user.name}'),
          subtitle: Text(user.isAdmin ? 'مسؤول' : 'عامل'),
        ),
        const SizedBox(height: 8),
        if (user.isAdmin)
          FilledButton.icon(
            onPressed: () => _editBusiness(context),
            icon: const Icon(Icons.edit),
            label: const Text('تعديل إعدادات النشاط'),
          ),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: Repo.i.signOut,
          icon: const Icon(Icons.logout),
          label: const Text('تسجيل الخروج'),
        ),
      ],
    );
  }
}
