import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

/// بيانات المتجر الافتراضية؛ يستطيع المسؤول تعديلها من التطبيق وتتزامن لكل الأجهزة.
class BusinessDefaults {
  static const name = 'العالمية لمواد البناء والسباكة وأدوات الورش';
  static const address = 'البوطة - كيلو 38 - خط تعز الرئيسي';
  static const phone1 = '734300088';
  static const phone2 = '784300088';
}

/// مفاتيح Firebase تُمرَّر وقت البناء عبر --dart-define (من GitHub Secrets)،
/// فلا حاجة لملف google-services.json ولا لأداة flutterfire.
class FirebaseConfig {
  static const _projectId = String.fromEnvironment('FB_PROJECT_ID');
  static const _senderId = String.fromEnvironment('FB_SENDER_ID');
  static const _bucket = String.fromEnvironment('FB_STORAGE_BUCKET');
  static const _authDomain = String.fromEnvironment('FB_AUTH_DOMAIN');
  static const _webKey = String.fromEnvironment('FB_WEB_API_KEY');
  static const _webApp = String.fromEnvironment('FB_WEB_APP_ID');
  static const _androidKey = String.fromEnvironment('FB_ANDROID_API_KEY');
  static const _androidApp = String.fromEnvironment('FB_ANDROID_APP_ID');
  static const _iosKey = String.fromEnvironment('FB_IOS_API_KEY');
  static const _iosApp = String.fromEnvironment('FB_IOS_APP_ID');

  static FirebaseOptions? get options {
    final String key;
    final String app;
    if (kIsWeb) {
      key = _webKey;
      app = _webApp;
    } else if (defaultTargetPlatform == TargetPlatform.iOS) {
      key = _iosKey;
      app = _iosApp;
    } else {
      key = _androidKey;
      app = _androidApp;
    }
    if (key.isEmpty || app.isEmpty || _projectId.isEmpty || _senderId.isEmpty) {
      return null;
    }
    return FirebaseOptions(
      apiKey: key,
      appId: app,
      messagingSenderId: _senderId,
      projectId: _projectId,
      storageBucket: _bucket.isEmpty ? null : _bucket,
      authDomain: (kIsWeb && _authDomain.isNotEmpty) ? _authDomain : null,
    );
  }
}
