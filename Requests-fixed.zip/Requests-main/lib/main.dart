import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'config.dart';
import 'pages.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  var ready = false;
  final options = FirebaseConfig.options;
  if (options != null) {
    try {
      await Firebase.initializeApp(options: options);
      // التخزين المحلي يعمل دون إنترنت ويُزامَن تلقائيًا عند عودته.
      FirebaseFirestore.instance.settings =
          const Settings(persistenceEnabled: true);
      ready = true;
    } catch (e) {
      debugPrint('Firebase init failed: $e');
    }
  }
  runApp(RequestsApp(firebaseReady: ready));
}

class RequestsApp extends StatelessWidget {
  const RequestsApp({super.key, required this.firebaseReady});
  final bool firebaseReady;

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'طلبات',
        debugShowCheckedModeBanner: false,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar'), Locale('en')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff1769aa)),
          useMaterial3: true,
          scaffoldBackgroundColor: const Color(0xfff5f7fa),
        ),
        home: firebaseReady ? const AuthGate() : const SetupNeededPage(),
      );
}
