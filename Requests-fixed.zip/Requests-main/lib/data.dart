import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';

import 'config.dart';
import 'util.dart';

class AppUser {
  AppUser({
    required this.uid,
    required this.name,
    required this.role,
    required this.approved,
  });

  final String uid;
  final String name;
  final String role;
  final bool approved;

  bool get isAdmin => role == 'admin' && approved;

  factory AppUser.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? <String, dynamic>{};
    return AppUser(
      uid: d.id,
      name: (m['name'] ?? '').toString(),
      role: (m['role'] ?? 'worker').toString(),
      approved: m['approved'] == true,
    );
  }
}

class Item {
  Item({
    required this.id,
    required this.name,
    required this.category,
    required this.unit,
  });

  final String id;
  final String name;
  final String category;
  final String unit;

  factory Item.fromDoc(QueryDocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data();
    return Item(
      id: d.id,
      name: (m['name'] ?? '').toString(),
      category: (m['category'] ?? '').toString(),
      unit: (m['unit'] ?? 'حبة').toString(),
    );
  }
}

class Req {
  Req({
    required this.id,
    required this.itemId,
    required this.itemName,
    required this.qty,
    required this.note,
    required this.workerId,
    required this.workerName,
    required this.status,
    required this.createdAt,
    required this.pending,
  });

  final String id;
  final String itemId;
  final String itemName;
  final double qty;
  final String note;
  final String workerId;
  final String workerName;
  final String status;
  final DateTime createdAt;

  /// true = لم يصل للخادم بعد (محفوظ محليًا وينتظر الإنترنت).
  final bool pending;

  factory Req.fromDoc(QueryDocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data();
    final ts = m['createdAt'];
    return Req(
      id: d.id,
      itemId: (m['itemId'] ?? '').toString(),
      itemName: (m['itemName'] ?? '').toString(),
      qty: (m['qty'] as num?)?.toDouble() ?? 0,
      note: (m['note'] ?? '').toString(),
      workerId: (m['workerId'] ?? '').toString(),
      workerName: (m['workerName'] ?? '').toString(),
      status: (m['status'] ?? 'جديد').toString(),
      createdAt: ts is Timestamp ? ts.toDate() : DateTime.now(),
      pending: d.metadata.hasPendingWrites,
    );
  }
}

class Business {
  Business({
    required this.name,
    required this.address,
    required this.phone1,
    required this.phone2,
    required this.logoB64,
  });

  final String name;
  final String address;
  final String phone1;
  final String phone2;
  final String logoB64;

  late final Uint8List? logoBytes = _decode(logoB64);

  static Uint8List? _decode(String s) {
    if (s.isEmpty) return null;
    try {
      return base64Decode(s);
    } catch (_) {
      return null;
    }
  }

  factory Business.defaults() => Business(
        name: BusinessDefaults.name,
        address: BusinessDefaults.address,
        phone1: BusinessDefaults.phone1,
        phone2: BusinessDefaults.phone2,
        logoB64: '',
      );

  factory Business.fromMap(Map<String, dynamic>? m) {
    String pick(String key, String fallback) {
      final v = (m?[key] ?? '').toString().trim();
      return v.isEmpty ? fallback : v;
    }

    return Business(
      name: pick('name', BusinessDefaults.name),
      address: pick('address', BusinessDefaults.address),
      phone1: pick('phone1', BusinessDefaults.phone1),
      phone2: pick('phone2', BusinessDefaults.phone2),
      logoB64: (m?['logoB64'] ?? '').toString(),
    );
  }
}

/// نقطة الوصول الوحيدة للبيانات.
/// ملاحظة مهمة: عمليات الكتابة لا تُنتظر (fire-and-forget) لأن Firestore
/// لا يُكمل الـ Future دون إنترنت؛ الكتابة تُحفظ محليًا فورًا وتُرسل تلقائيًا.
class Repo {
  Repo._();
  static final Repo i = Repo._();

  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final StreamController<String> _errors = StreamController<String>.broadcast();
  String? _pendingName;

  /// أخطاء رفض الخادم (مثل نقص الصلاحية) لعرضها للمستخدم.
  Stream<String> get errors => _errors.stream;

  void _fire(Future<void> f) {
    f.catchError((Object e) {
      debugPrint('Firestore write failed: $e');
      _errors.add('تعذر حفظ التغيير: $e');
    });
  }

  // ---------------- المصادقة ----------------
  Future<void> signIn(String username, String password) async {
    await _auth.signInWithEmailAndPassword(
      email: usernameToEmail(username),
      password: password,
    );
  }

  Future<void> signUp(String username, String password, String name) async {
    _pendingName = name;
    final cred = await _auth.createUserWithEmailAndPassword(
      email: usernameToEmail(username),
      password: password,
    );
    try {
      await cred.user?.updateDisplayName(name);
    } catch (_) {}
  }

  Future<void> signOut() => _auth.signOut();

  // ---------------- المستخدمون ----------------
  Stream<DocumentSnapshot<Map<String, dynamic>>> userDoc(String uid) =>
      _db.collection('users').doc(uid).snapshots();

  /// ينشئ ملف المستخدم (عامل غير معتمد) إن لم يوجد. يستخدم transaction
  /// حتى لا يستبدل ملف مسؤول موجود بالخطأ، ولا ينجح دون اتصال.
  Future<void> ensureUserDoc(User u) async {
    final ref = _db.collection('users').doc(u.uid);
    final name = normalize(_pendingName ?? u.displayName ?? '');
    final fallback = (u.email ?? '').split('@').first;
    await _db.runTransaction((tx) async {
      final snap = await tx.get(ref);
      if (!snap.exists) {
        tx.set(ref, {
          'name': name.isEmpty ? fallback : name,
          'role': 'worker',
          'approved': false,
          'createdAt': FieldValue.serverTimestamp(),
        });
      }
    });
  }

  Stream<List<AppUser>> users() => _db.collection('users').snapshots().map((s) {
        final l = s.docs.map(AppUser.fromDoc).toList();
        l.sort((a, b) {
          if (a.approved != b.approved) return a.approved ? 1 : -1;
          return a.name.compareTo(b.name);
        });
        return l;
      });

  void setUser(String uid, {bool? approved, String? role}) {
    final data = <String, Object?>{};
    if (approved != null) data['approved'] = approved;
    if (role != null) data['role'] = role;
    if (data.isEmpty) return;
    _fire(_db.collection('users').doc(uid).update(data));
  }

  // ---------------- الأصناف ----------------
  Stream<List<Item>> items() => _db.collection('items').snapshots().map((s) {
        final l = s.docs.map(Item.fromDoc).toList();
        l.sort((a, b) {
          final c = a.category.compareTo(b.category);
          return c != 0 ? c : a.name.compareTo(b.name);
        });
        return l;
      });

  void addItem({
    required String name,
    required String category,
    required String unit,
    required AppUser user,
  }) {
    _fire(_db.collection('items').doc().set({
      'name': name,
      'category': category,
      'unit': unit,
      'createdBy': user.uid,
      'createdAt': FieldValue.serverTimestamp(),
    }));
  }

  void updateItem(
    String id, {
    required String name,
    required String category,
    required String unit,
  }) {
    _fire(_db.collection('items').doc(id).update({
      'name': name,
      'category': category,
      'unit': unit,
      'updatedAt': FieldValue.serverTimestamp(),
    }));
  }

  void deleteItem(String id) => _fire(_db.collection('items').doc(id).delete());

  // ---------------- الطلبات ----------------
  Stream<List<Req>> requests(AppUser u) {
    Query<Map<String, dynamic>> q = _db.collection('requests');
    if (!u.isAdmin) q = q.where('workerId', isEqualTo: u.uid);
    return q.snapshots(includeMetadataChanges: true).map((s) {
      final l = s.docs.map(Req.fromDoc).toList();
      l.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return l;
    });
  }

  void addRequest({
    required Item item,
    required double qty,
    required String note,
    required AppUser user,
  }) {
    _fire(_db.collection('requests').doc().set({
      'itemId': item.id,
      'itemName': item.name,
      'qty': qty,
      'note': note,
      'workerId': user.uid,
      'workerName': user.name,
      'status': 'جديد',
      'createdAt': FieldValue.serverTimestamp(),
    }));
  }

  void setStatus(String id, String status) {
    _fire(_db.collection('requests').doc(id).update({
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
    }));
  }

  void deleteRequest(String id) =>
      _fire(_db.collection('requests').doc(id).delete());

  // ---------------- بيانات المتجر ----------------
  Stream<Business> business() => _db
      .collection('settings')
      .doc('business')
      .snapshots()
      .map((d) => Business.fromMap(d.data()));

  void saveBusiness(Map<String, Object?> data) {
    _fire(_db.collection('settings').doc('business').set({
      ...data,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true)));
  }
}
