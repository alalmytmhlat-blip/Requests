# طلبات — تطبيق طلبات الأصناف الناقصة

تطبيق Flutter عربي (RTL) لتسجيل نواقص الأصناف من العمال ومراجعتها من المسؤول،
بمزامنة سحابية فورية بين **أي عدد من الأجهزة**.

| المنصة | كيف تعمل |
|---|---|
| أندرويد | ملف APK من GitHub Actions |
| آيفون / آيباد | تطبيق الويب (Safari ← مشاركة ← «إضافة إلى الشاشة الرئيسية») |
| كمبيوتر / أي متصفح | تطبيق الويب نفسه |

## المزايا
- دخول بحساب (اسم دخول + كلمة مرور) وأدوار حقيقية: **مسؤول** و**عامل**، والمسؤول يعتمد الحسابات الجديدة.
- العامل يرى طلباته فقط؛ المسؤول يرى الكل ويغيّر الحالة (جديد، قيد التجهيز، تم توفيره، غير متوفر) أو يحذف.
- كتالوج أصناف مشترك (إضافة للجميع، تعديل/حذف للمسؤول) مع بحث.
- بيانات المتجر (الاسم، العنوان، الهاتفان، الشعار) تتزامن لكل الأجهزة، ويعدّلها المسؤول فقط.
- **يعمل دون إنترنت**: الطلب يُحفظ على الجهاز (أيقونة سحابة) ويُرسل تلقائيًا عند عودة الاتصال.
- تخطيط متجاوب: شريط سفلي للجوال وشريط جانبي للشاشات الكبيرة.

## الإعداد (مرة واحدة)

### 1) مشروع Firebase
1. أنشئ مشروعًا في https://console.firebase.google.com
2. **Authentication ← Sign-in method**: فعّل **Email/Password**.
3. **Firestore Database**: أنشئ قاعدة بيانات (Production mode).
4. **Project settings ← Your apps**: أضف تطبيقين:
   - **Android** بحزمة `com.alalamiya.requests`
   - **Web** (بأي اسم)
   - (اختياري) iOS للنشر الأصلي لاحقًا
5. انسخ من إعدادات كل تطبيق: `apiKey` و`appId`، ومن إعدادات المشروع: `projectId` و`messagingSenderId` و`storageBucket`، ومن تطبيق الويب: `authDomain`.

### 2) أسرار GitHub
في المستودع: **Settings ← Secrets and variables ← Actions ← New repository secret**

| الاسم | القيمة |
|---|---|
| `FB_PROJECT_ID` | projectId |
| `FB_SENDER_ID` | messagingSenderId |
| `FB_STORAGE_BUCKET` | storageBucket |
| `FB_AUTH_DOMAIN` | authDomain (للويب) |
| `FB_ANDROID_API_KEY` / `FB_ANDROID_APP_ID` | من تطبيق Android |
| `FB_WEB_API_KEY` / `FB_WEB_APP_ID` | من تطبيق Web |
| `FB_IOS_API_KEY` / `FB_IOS_APP_ID` | (اختياري) |

### 3) قواعد الأمان
```bash
npm i -g firebase-tools
firebase login
firebase use --add          # اختر مشروعك
firebase deploy --only firestore:rules
```
> لا تُشغّل التطبيق ببيانات حقيقية قبل نشر القواعد؛ فهي ما يمنع العامل من الاطلاع على طلبات غيره أو ترقية نفسه.

### 4) البناء
ادفع إلى فرع `main` (أو شغّل **Actions ← Build APK and Web** يدويًا) ثم نزّل:
- `requests-android-apk` ← ثبّته على أجهزة أندرويد.
- `requests-web` ← انشره (الخطوة 6).

### 5) أول مسؤول
1. افتح التطبيق وأنشئ حسابك («عامل جديد؟ أنشئ حسابًا»).
2. في Firebase Console ← Firestore ← مجموعة `users` ← مستندك: غيّر `role` إلى `admin` و`approved` إلى `true`.
3. أعد فتح التطبيق: ستظهر تبويبات المسؤول. بعدها تعتمد بقية العمال من تبويب **المستخدمون**.

### 6) نشر الويب (للآيفون والكمبيوتر)
نزّل artifact `requests-web` وفك الضغط إلى `build/web` ثم:
```bash
firebase deploy --only hosting
```
وأضف نطاق الاستضافة في **Authentication ← Settings ← Authorized domains** إن لم يكن مضافًا.

## ملاحظات
- عند أول بناء ناجح، ثبّت إصدار Flutter في `.github/workflows/build.yml` (`flutter-version`) لتجنب تغيّر الإصدار بين البناءات.
- ملف APK يُوقَّع حاليًا بمفتاح debug يتغير في كل بناء على GitHub، فلا يمكن تحديثه فوق نسخة مثبتة (يلزم حذفها أولًا). لنشر رسمي أنشئ keystore ثابتًا وأضفه كسر.
- قواعد الأمان تقرأ مستند المستخدم عند كل عملية (قراءة إضافية مفوترة)، وهو مقبول لحجم متجر.
- راجع `AUDIT.md` لتقرير تدقيق المشروع الأصلي وما تم إصلاحه.
