import 'package:flutter_test/flutter_test.dart';
import 'package:requests/util.dart';

void main() {
  group('parseQty', () {
    test('يقبل الأرقام العربية والفارسية', () {
      expect(parseQty('٣'), 3);
      expect(parseQty('۱۲'), 12);
    });

    test('يقبل الفاصلة العشرية بأنواعها', () {
      expect(parseQty('٢٫٥'), 2.5);
      expect(parseQty('1,5'), 1.5);
      expect(parseQty('2.25'), 2.25);
    });

    test('يرفض الصفر والسالب وغير الرقمي', () {
      expect(parseQty('0'), isNull);
      expect(parseQty('-2'), isNull);
      expect(parseQty('abc'), isNull);
      expect(parseQty(''), isNull);
    });
  });

  group('أدوات النصوص', () {
    test('formatQty', () {
      expect(formatQty(3.0), '3');
      expect(formatQty(2.5), '2.5');
    });

    test('normalize يوحّد المسافات', () {
      expect(normalize('  مفتاح   ربط  '), 'مفتاح ربط');
    });

    test('validUsername', () {
      expect(validUsername('734300088'), isTrue);
      expect(validUsername('ab'), isFalse);
      expect(validUsername('علي'), isFalse);
    });

    test('usernameToEmail', () {
      expect(usernameToEmail(' Ali.99 '), 'ali.99@alalamiya.app');
    });
  });
}
